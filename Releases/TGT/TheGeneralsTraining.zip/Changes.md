﻿#

## Bros

### Global

* Animation of climbing a ladder (optional)
* Animation of pushing a box (optional)
* When you swap your bro alive, you keep the special ammo( Time Slow, AirStrike, Remote Controle Car, Mech Drop, ect.) (optional)
* Throw Bruisers if steroids are on (optional)
* Fix stealth in grass
* Player will not move/shoot when typing in chat
* Ammo box will not be takes if the player has pocketed ammo

### Brade

* Put back the old brade's glaive sprite (optional)

### Bro Hard

* 15% Faster in enclosed spaces (optional)

### Brochete

* Alternate special animatoin (optional)

### Broden

* The enemies become electric when they are throw (optional)

### Brominator

* Throw Bruisers if Brominator is in his metal form (optional)

### Broney Ross

* Pistols has the sound from Bro Hard's pistols

### Bronnar Jensen

* Shoot sticky grenades at his feet

### Buffy

* Convert basic mooks into villager with holy water (optional)

### Chev Brolios

* No more recoil (optional)
* During adrenaline, press the special button again to use up one of his lives to infuse chev with fire and electricity (optional)

### Desperabro

* Mariachis no longer steal lives from Desperabro (optional)

### Dirty Harry

* DON'T WORK Reload On punch (optional)

### Double Bro Seven

* Add the fifth special of 007, a tear gas (optional)
* 007 is less accurate when he has drink more than 3 cocktails (optional)
* Throw the tear gas at his feet

### Lee Broxmas

* Change the knife sprite to Brade's knife sprite

### Indiana Brones

* Fix the No Ticket's achievement

### Rambro

* In the Rambro's menu, you can trigger unused animations

### Scorpion Bro

* Melee in stealth mode (optional)

### Seth Brondle

* Not cover by acid if he has at least one special left. (optional)

### The Brolander

* If the brolander has more than 2 special ammo, the enemies become electric when they are throw (optional)

### Trent Broser

* Change the attack sound to a non-silent one
* Change the special grenade to the Brodell Walker's grenade

### Xena

* Press special when the chakram is out, and Xena will catch it (optional)

## Projectiles

### Chakram

* Is caught after xena called it (optional)

### Grenades

* Don't explode if not visible (optional)

## HUD

* Icon for the fifth special of 007
* Face Hugger (optional)